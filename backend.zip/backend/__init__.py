"""Backend package initialization."""
